//-----------------------------------------------------------------------
// <copyright file="Class.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace $safeprojectname$
{
    using System;

    /// <summary>
    /// Definition for Class
    /// </summary>
    public class Class
    {
    }
}

