//-----------------------------------------------------------------------
// <copyright file="Class.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace $safeprojectname$
{
    using System;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// Definition for Program
    /// </summary>
    public class Program
    {
        [EntryPoint]
        public static void Main()
        {
        }
    }
}

