﻿//-----------------------------------------------------------------------
// <copyright file="$fileinputname$.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace $rootnamespace$
{
	using System;

	/// <summary>
	/// Definition for $safeitemrootname$
	/// </summary>
	public class $safeitemrootname$
	{
	}
}
